export default { darkMode:['class'], content:['./app/**/*.{ts,tsx}','./components/**/*.{ts,tsx}','./pages/**/*.{ts,tsx}'], theme:{ extend:{ borderRadius:{ '2xl':'1rem' } } }, plugins:[] }
