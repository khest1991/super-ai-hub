# Super AI Hub — Ready

Local run:
```
npm i
cp .env.example .env
npx prisma migrate dev --name init
npx ts-node prisma/seed.ts
npm run dev
```
