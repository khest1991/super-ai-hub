'use client'
import { useState } from "react"; import { Button } from "@/components/ui/button"; import { Card, CardContent } from "@/components/ui/card"; import { Input } from "@/components/ui/input";
export default function MainLanding(){ const [lang,setLang]=useState<'ar'|'en'>('ar'); const t={ ar:{title:'منصتك الذكية الشاملة',cta:'ابدأ مجانًا',pricing:'الأسعار'}, en:{title:'Your all‑in‑one AI platform',cta:'Start Free',pricing:'Pricing'} }[lang];
return(<main className={`${lang==='ar'?'direction-rtl':'direction-ltr'} p-10 max-w-5xl mx-auto`}>
  <header className="flex justify-between items-center mb-8"><h1 className="font-bold text-2xl text-indigo-600">Super AI Hub</h1><div className="flex gap-2"><Button variant="ghost" onClick={()=>setLang(lang==='ar'?'en':'ar')}>{lang==='ar'?'English':'العربية'}</Button><a href="/pricing"><Button>{t.pricing}</Button></a></div></header>
  <section className="text-center mb-8"><h2 className="text-4xl font-extrabold mb-3">{t.title}</h2><p className="text-gray-600">كتابة نصوص، توليد صور، تعليم، وأدوات أعمال.</p><div className="mt-6"><a href="/pricing"><Button size="lg">{t.cta}</Button></a></div></section>
  <section className="grid md:grid-cols-3 gap-4">{['✍️ كتابة','🎨 صور','📊 أعمال'].map((x,i)=>(<Card key={i}><CardContent className="p-6">{x}</CardContent></Card>))}</section>
</main>) }
