'use client'
import { useState } from 'react'; import { Button } from '@/components/ui/button'; import { Card, CardContent } from '@/components/ui/card'; import { Input } from '@/components/ui/input'; import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs';
export default function Dashboard(){ const [prompt,setPrompt]=useState(''); const [text,setText]=useState(''); const [imgPrompt,setImgPrompt]=useState(''); const [img,setImg]=useState<string|null>(null);
const call=async(url:string,body:any)=>{const r=await fetch(url,{method:'POST',headers:{'Content-Type':'application/json','X-User-ID':'00000000-0000-0000-0000-000000000000'},body:JSON.stringify(body)}); return r.json();};
return(<main className="p-6 max-w-4xl mx-auto"><h1 className="text-2xl font-bold mb-4">Dashboard</h1>
<Tabs defaultValue="text"><TabsList className="grid grid-cols-2 gap-2 mb-6"><TabsTrigger value="text">Text</TabsTrigger><TabsTrigger value="image">Image</TabsTrigger></TabsList>
<TabsContent value="text"><Card><CardContent className="p-6"><Input placeholder="اكتب الطلب" value={prompt} onChange={e=>setPrompt(e.target.value)} className="mb-3"/><Button onClick={async()=>{const d=await call('/api/generate/text',{prompt}); setText(d.text||d.error)}}>Generate</Button>{text&&<div className="mt-4 p-4 bg-gray-100 rounded-xl">{text}</div>}</CardContent></Card></TabsContent>
<TabsContent value="image"><Card><CardContent className="p-6"><Input placeholder="صف الصورة" value={imgPrompt} onChange={e=>setImgPrompt(e.target.value)} className="mb-3"/><Button onClick={async()=>{const d=await call('/api/generate/image',{prompt:imgPrompt}); setImg(d.url)}}>Generate</Button>{img&&<img className="mt-4 rounded-xl shadow" src={img}/>}</CardContent></Card></TabsContent>
</Tabs></main>) }
