'use client'
import { useState } from 'react'; import { Button } from '@/components/ui/button';
export default function Pricing(){ const [email,setEmail]=useState('demo@aihub.local'); const post=async(u:string,b:any)=>{const r=await fetch(u,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(b)}); return r.json();};
return(<main className="p-6 max-w-3xl mx-auto"><h1 className="text-3xl font-bold mb-2">Pricing</h1><input className="border rounded-2xl px-3 py-2 mb-4" value={email} onChange={e=>setEmail(e.target.value)}/>
<div className="grid md:grid-cols-3 gap-4">{['free','pro','business'].map(p=>(<div key={p} className={`border rounded-2xl p-4 ${p==='pro'?'border-indigo-500 bg-indigo-50':''}`}><h3 className="font-semibold">{p.toUpperCase()}</h3><Button onClick={async()=>{const d=await post('/api/checkout/subscription',{planId:p,email}); if(d.url) location.href=d.url; else alert(d.error||'Set Stripe env vars');}}>Choose</Button></div>))}</div></main>) }
